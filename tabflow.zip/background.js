﻿// TabFlow Background Service Worker
const LICENSE_KEY = "tabflow_license";
const WORKSPACES_KEY = "tabflow_workspaces";
const CURRENT_WS_KEY = "tabflow_current_ws";

// ========== License Management ==========

async function checkLicense() {
  const data = await chrome.storage.sync.get(LICENSE_KEY);
  return data[LICENSE_KEY] || null;
}

async function getLicenseTier() {
  const lic = await checkLicense();
  if (!lic) return "free";
  // Simple HMAC-like validation
  const expected = await hashLicense(lic.email);
  if (lic.key === expected) return lic.tier || "pro";
  return "free";
}

async function hashLicense(email) {
  const enc = new TextEncoder().encode(email + "_tabflow_salt_2024");
  const hash = await crypto.subtle.digest("SHA-256", enc);
  return Array.from(new Uint8Array(hash))
    .map(b => b.toString(16).padStart(2, "0")).join("").slice(0, 16);
}

async function activateLicense(email) {
  const key = await hashLicense(email);
  await chrome.storage.sync.set({
    [LICENSE_KEY]: { email, key, tier: "pro", activatedAt: Date.now() }
  });
  return true;
}

// ========== Workspace Management ==========

async function getAllWorkspaces() {
  const data = await chrome.storage.sync.get(WORKSPACES_KEY);
  return data[WORKSPACES_KEY] || {};
}

async function saveWorkspace(name) {
  const tabs = await chrome.tabs.query({ currentWindow: true });
  const ws = {
    name,
    createdAt: Date.now(),
    tabCount: tabs.length,
    tabs: tabs.map(t => ({
      url: t.url,
      title: t.title,
      favIconUrl: t.favIconUrl,
      pinned: t.pinned
    }))
  };
  const all = await getAllWorkspaces();
  all[name] = ws;
  await chrome.storage.sync.set({ [WORKSPACES_KEY]: all });
  return ws;
}

async function deleteWorkspace(name) {
  const all = await getAllWorkspaces();
  delete all[name];
  await chrome.storage.sync.set({ [WORKSPACES_KEY]: all });
}

async function restoreWorkspace(name) {
  const all = await getAllWorkspaces();
  const ws = all[name];
  if (!ws) return false;
  for (const tab of ws.tabs) {
    await chrome.tabs.create({ url: tab.url, pinned: tab.pinned });
  }
  return true;
}

// ========== Message Handlers ==========

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    switch (msg.action) {
      case "getWorkspaces":
        sendResponse({ workspaces: await getAllWorkspaces() });
        break;
      case "saveWorkspace":
        sendResponse({ workspace: await saveWorkspace(msg.name) });
        break;
      case "deleteWorkspace":
        await deleteWorkspace(msg.name);
        sendResponse({ success: true });
        break;
      case "restoreWorkspace":
        sendResponse({ success: await restoreWorkspace(msg.name) });
        break;
      case "getLicenseTier":
        sendResponse({ tier: await getLicenseTier() });
        break;
      case "activateLicense":
        sendResponse({ success: await activateLicense(msg.email) });
        break;
      case "getAllTabs":
        const tabs = await chrome.tabs.query({ currentWindow: true });
        sendResponse({ tabs: tabs.map(t => ({ url: t.url, title: t.title })) });
        break;
      default:
        sendResponse({ error: "Unknown action" });
    }
  })();
  return true;
});

// Keyboard shortcuts
chrome.commands.onCommand.addListener(async (cmd) => {
  if (cmd === "save-workspace") {
    const name = `workspace_${new Date().toLocaleDateString("zh-CN")}_${Date.now() % 100000}`;
    await saveWorkspace(name);
  }
});
