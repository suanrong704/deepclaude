﻿// TabFlow Options Page
document.addEventListener("DOMContentLoaded", init);

async function init() {
  await refreshLicense();
  document.getElementById("activateBtn").addEventListener("click", onActivate);
  document.getElementById("exportBtn").addEventListener("click", onExport);
  document.getElementById("clearBtn").addEventListener("click", onClear);
}

async function refreshLicense() {
  const resp = await chrome.runtime.sendMessage({ action: "getLicenseTier" });
  const div = document.getElementById("licenseStatus");
  if (resp.tier === "pro") {
    div.innerHTML = '<span class="tier-badge tier-pro">Pro</span> 已激活 — 享受所有高级功能';
  } else {
    div.innerHTML = '<span class="tier-badge tier-free">免费版</span> — 最多 10 个工作区';
  }
}

async function onActivate() {
  const email = document.getElementById("emailInput").value.trim();
  const status = document.getElementById("activateStatus");
  if (!email || !email.includes("@")) {
    status.className = "status error";
    status.textContent = "请输入有效邮箱地址";
    return;
  }
  const resp = await chrome.runtime.sendMessage({ action: "activateLicense", email });
  if (resp.success) {
    status.className = "status success";
    status.textContent = "🎉 Pro 已激活！";
    await refreshLicense();
  } else {
    status.className = "status error";
    status.textContent = "激活失败，请重试";
  }
}

async function onExport() {
  const resp = await chrome.runtime.sendMessage({ action: "getWorkspaces" });
  const json = JSON.stringify(resp.workspaces, null, 2);
  const blob = new Blob([json], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `tabflow_backup_${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
  document.getElementById("dataStatus").className = "status success";
  document.getElementById("dataStatus").textContent = "✅ 数据已导出";
}

async function onClear() {
  if (!confirm("确定要清除所有工作区数据吗？此操作不可撤销！")) return;
  const resp = await chrome.runtime.sendMessage({ action: "getWorkspaces" });
  for (const name of Object.keys(resp.workspaces || {})) {
    await chrome.runtime.sendMessage({ action: "deleteWorkspace", name });
  }
  document.getElementById("dataStatus").className = "status success";
  document.getElementById("dataStatus").textContent = "✅ 所有数据已清除";
}
