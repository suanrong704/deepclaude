﻿// TabFlow Popup Controller
let currentTier = "free";
const FREE_LIMIT = 10;

// ========== Helpers ==========
function $(id) { return document.getElementById(id); }
function showToast(msg) {
  const t = $("toast");
  t.textContent = msg;
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 2000);
}

// ========== Init ==========
document.addEventListener("DOMContentLoaded", async () => {
  await refreshUI();
  $("saveBtn").addEventListener("click", onSave);
  $("wsNameInput").addEventListener("keydown", e => { if (e.key === "Enter") onSave(); });
  $("upgradeLink").addEventListener("click", onUpgrade);
  $("optionsLink").addEventListener("click", () => chrome.runtime.openOptionsPage());
});

async function refreshUI() {
  const tierResp = await chrome.runtime.sendMessage({ action: "getLicenseTier" });
  currentTier = tierResp.tier;
  $("tierBadge").textContent = currentTier === "pro" ? "Pro" : "免费版";
  $("tierBadge").className = "badge" + (currentTier === "pro" ? " pro" : "");
  $("wsLimit").textContent = currentTier === "pro" ? "∞" : FREE_LIMIT;
  $("proSection").style.display = currentTier === "pro" ? "none" : "block";
  $("upgradeLink").style.display = currentTier === "pro" ? "none" : "inline";

  const resp = await chrome.runtime.sendMessage({ action: "getWorkspaces" });
  const workspaces = resp.workspaces || {};
  const keys = Object.keys(workspaces);
  $("wsCount").textContent = keys.length;

  const list = $("workspaceList");
  list.innerHTML = "";
  if (keys.length === 0) {
    $("emptyState").style.display = "block";
  } else {
    $("emptyState").style.display = "none";
    keys.sort((a, b) => workspaces[b].createdAt - workspaces[a].createdAt);
    for (const name of keys) {
      const ws = workspaces[name];
      const item = document.createElement("div");
      item.className = "workspace-item";
      const date = new Date(ws.createdAt).toLocaleDateString("zh-CN");
      item.innerHTML = `
        <div class="workspace-info">
          <div class="workspace-name">${escapeHtml(name)}</div>
          <div class="workspace-meta">${ws.tabCount} 个标签 · ${date}</div>
        </div>
        <button class="btn btn-restore" data-name="${escapeHtml(name)}">恢复</button>
        <button class="btn btn-danger" data-name="${escapeHtml(name)}">✕</button>
      `;
      list.appendChild(item);
    }
    // Bind events
    list.querySelectorAll(".btn-restore").forEach(btn => {
      btn.addEventListener("click", () => onRestore(btn.dataset.name));
    });
    list.querySelectorAll(".btn-danger").forEach(btn => {
      btn.addEventListener("click", () => onDelete(btn.dataset.name));
    });
  }
}

function escapeHtml(s) { return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }

// ========== Actions ==========
async function onSave() {
  const name = $("wsNameInput").value.trim();
  if (!name) { showToast("请输入工作区名称"); return; }

  const resp = await chrome.runtime.sendMessage({ action: "getWorkspaces" });
  const count = Object.keys(resp.workspaces || {}).length;
  if (currentTier === "free" && count >= FREE_LIMIT && !resp.workspaces[name]) {
    showToast("免费版最多保存 " + FREE_LIMIT + " 个工作区，请升级 Pro");
    return;
  }

  await chrome.runtime.sendMessage({ action: "saveWorkspace", name });
  $("wsNameInput").value = "";
  showToast("✅ 工作区已保存");
  await refreshUI();
}

async function onRestore(name) {
  await chrome.runtime.sendMessage({ action: "restoreWorkspace", name });
  showToast("🔄 正在恢复工作区...");
}

async function onDelete(name) {
  if (!confirm(`确定删除工作区 "${name}"？`)) return;
  await chrome.runtime.sendMessage({ action: "deleteWorkspace", name });
  showToast("🗑 已删除");
  await refreshUI();
}

async function onUpgrade() {
  const email = prompt("输入你的邮箱以激活 Pro 许可证：");
  if (!email || !email.includes("@")) { showToast("请输入有效邮箱"); return; }
  const resp = await chrome.runtime.sendMessage({ action: "activateLicense", email });
  if (resp.success) {
    showToast("🎉 Pro 已激活！感谢支持");
    await refreshUI();
  }
}

// Auto-refresh on focus
window.addEventListener("focus", refreshUI);
